package edu.hm.dako.chat.server;

/**
 * @author Paul Mandl
 */
public class ServerStartData {
	String startTime;

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
}
